#ifndef _COLORS_H
#define _COLORS_H

#define FOREGROUND_COLOR 252 // three font colors, with index 252 being the darkest
#define BACKGROUND_COLOR 255
#define MIN_COLOR_VALUE 0
#define MAX_COLOR_VALUE 251


#endif // _COLORS_H
