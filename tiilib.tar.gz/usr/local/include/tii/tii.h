#ifndef _TII_HEADER_H
#define _TII_HEADER_H

#define TII_LIB_VERSION 1.0
#define TII_LIB_VERSION_STRING "0101"

#include <stdbool.h>
#include <stdint.h>


#endif // _TII_HEADER_H
